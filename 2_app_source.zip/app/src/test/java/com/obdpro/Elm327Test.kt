package com.obdpro

import com.obdpro.obd.Elm327
import com.obdpro.obd.Pids
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Elm327Test {
    private fun elm(extra: Map<String, String> = emptyMap()): Elm327 =
        Elm327(FakeTransport(RealMazda5.script + extra))

    @Test fun adapterNameIsCleanedFromGarbage() = runBlocking {
        val e = elm(); e.initialize()
        assertEquals("ELM327 v1.5", e.adapterName)
    }

    @Test fun supportedPidsMatchRealCar() = runBlocking {
        val e = elm(); e.initialize()
        val s = e.supportedPids()
        for (p in listOf(0x04, 0x05, 0x0B, 0x0C, 0x0D, 0x10, 0x11, 0x23, 0x31, 0x33, 0x42, 0x49)) {
            assertTrue("PID %02X يجب أن يكون مدعومًا".format(p), p in s)
        }
        for (p in listOf(0x06, 0x07, 0x1F, 0x2F, 0x5C)) {
            assertFalse("PID %02X يجب ألا يكون مدعومًا".format(p), p in s)
        }
    }

    @Test fun vinFromMultiFrameResponse() = runBlocking {
        val e = elm(); e.initialize()
        assertEquals("JMZCR19T670175329", e.vin())
    }

    @Test fun protocolDetectedAsCan() = runBlocking {
        val e = elm(); e.detectProtocol()
        assertEquals("6", e.protocolNumber)
    }

    @Test fun noStoredNorPendingCodes() = runBlocking {
        val e = elm(); e.detectProtocol()
        assertEquals(emptyList<String>(), e.storedCodes())
        assertEquals(emptyList<String>(), e.pendingCodes())
    }

    @Test fun storedCodesParsedOnCan() = runBlocking {
        val e = elm(mapOf("03" to "430202990171\r\r")); e.detectProtocol()
        assertEquals(listOf("P0299", "P0171"), e.storedCodes())
    }

    @Test fun storedCodesParsedOnNonCan() = runBlocking {
        val e = Elm327(FakeTransport(RealMazda5.script + mapOf("ATDPN" to "A3\r\r", "03" to "43 01 33 00 00 00 00\r\r")))
        e.detectProtocol()
        assertEquals(listOf("P0133"), e.storedCodes())
    }

    @Test fun readinessMatchesRealCar() = runBlocking {
        val e = elm()
        val r = e.readiness()
        assertNotNull(r)
        assertFalse(r!!.milOn)
        assertEquals(0, r.dtcCount)
        assertEquals(listOf("المكونات الشاملة" to false, "نظام EGR" to true), r.monitors)
    }

    @Test fun rpmDecoding() = runBlocking {
        val e = elm()
        assertEquals(700.0, e.readPid(Pids.all[Pids.RPM]!!)!!, 0.01)
        assertEquals(60.0, e.readPid(Pids.all[Pids.SPEED]!!)!!, 0.01)
        assertEquals(80.0, e.readPid(Pids.all[Pids.COOLANT]!!)!!, 0.01)
    }

    @Test fun unsupportedPidReturnsNull() = runBlocking {
        val e = elm()
        assertNull(e.readPid(Pids.all[Pids.LTFT]!!))
    }

    @Test fun countersParsed() = runBlocking {
        val e = elm()
        val c = e.counters()
        assertEquals(80, c["kmClear"])
        assertEquals(21, c["warmups"])
        assertNull(c["minClear"])
    }

    @Test fun mode06FindsFailingTest() = runBlocking {
        val e = elm(mapOf(
            "0600" to "4600C0000001\r\r",
            "0620" to "462080000000\r\r",
            "0601" to "4601028E0064005000C8\r\r",
            "0621" to "4621010C020000000100\r\r"
        ))
        val mids = e.mode06Supported()
        assertEquals(listOf(1, 2, 0x21), mids)
        val t1 = e.mode06Read(1)
        assertEquals(1, t1.size)
        assertFalse(t1[0].failed)
        val t21 = e.mode06Read(0x21)
        assertEquals(1, t21.size)
        assertTrue(t21[0].failed)
    }
}
