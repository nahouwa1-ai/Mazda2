package com.obdpro

import com.obdpro.obd.ObdTransport

/** قناة وهمية: ترد بنص مسجّل لكل أمر، أو NO DATA. */
class FakeTransport(private val script: Map<String, String>) : ObdTransport {
    private var last = ""
    val sent = mutableListOf<String>()
    override suspend fun open() {}
    override fun close() {}
    override suspend fun write(command: String) {
        last = command.trim().uppercase()
        sent += last
    }
    override suspend fun readUntilPrompt(timeoutMs: Long): String = script[last] ?: "NO DATA\r\r"
}

/** ردود حقيقية التُقطت من Mazda 5 ديزل (VIN JMZCR19T…) عبر ELM327 v1.5 على CAN 11/500. */
object RealMazda5 {
    val script: Map<String, String> = mapOf(
        "ATZ" to "ATZ\rü\r\rELM327 v1.5\r\r",
        "ATE0" to "ATE0\rOK\r\r",
        "ATL0" to "OK\r\r", "ATS0" to "OK\r\r", "ATH0" to "OK\r\r", "ATAT1" to "OK\r\r", "ATSP0" to "OK\r\r",
        "0100" to "SEARCHING...\r4100983B8011\r\r",
        "0120" to "4120B001B01D\r\r",
        "0140" to "414044D00000\r\r",
        "ATDPN" to "A6\r\r",
        "0902" to "014\r0: 4902014A4D5A\r1: 43523139543637\r2: 30313735333239\r\r",
        "03" to "4300\r\r",
        "07" to "4700\r\r",
        "0101" to "410100448000\r\r",
        "010C" to "410C0AF0\r\r",
        "010D" to "410D3C\r\r",
        "0105" to "410578\r\r",
        "0131" to "41310050\r\r",
        "0130" to "413015\r\r"
    )
}
