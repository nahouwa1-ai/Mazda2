package com.obdpro

import com.obdpro.data.TripStore
import com.obdpro.obd.Boost
import com.obdpro.obd.DeepAnalyzer
import com.obdpro.obd.Diagnostics
import com.obdpro.obd.Dtc
import com.obdpro.obd.ObdException
import com.obdpro.obd.Pids
import com.obdpro.obd.Readiness
import com.obdpro.obd.Severity
import com.obdpro.obd.StreamTransport
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

class LogicTest {
    // ---- DTC ----
    @Test fun dtcDecode() {
        assertEquals("P0171", Dtc.decode(0x01, 0x71))
        assertEquals("P0299", Dtc.decode(0x02, 0x99))
        assertEquals("P0300", Dtc.decode(0x03, 0x00))
        assertEquals("C0035", Dtc.decode(0x40, 0x35))
        assertEquals("B0100", Dtc.decode(0x81, 0x00))
        assertEquals("U0100", Dtc.decode(0xC1, 0x00))
    }

    @Test fun dtcPairsSkipPaddingAndDuplicates() {
        assertEquals(listOf("P0299"), Dtc.parsePairs(listOf(0x02, 0x99, 0, 0, 0x02, 0x99)))
    }

    @Test fun dtcLookupKnownAndFallback() {
        assertEquals(Severity.WARN, Dtc.lookup("P0299").severity)
        assertEquals(Severity.CRIT, Dtc.lookup("P0217").severity)
        assertTrue(Dtc.lookup("P1234").title.isNotEmpty())
        assertTrue(Dtc.lookup("P0305").title.contains("5"))
    }

    // ---- Pids ----
    @Test fun pidFormulas() {
        assertEquals(88.0, Pids.all[Pids.COOLANT]!!.decode(intArrayOf(128)), 0.01)
        assertEquals(1726.0, Pids.all[Pids.RPM]!!.decode(intArrayOf(0x1A, 0xF8)), 0.01)
        assertEquals(0.0, Pids.all[Pids.STFT]!!.decode(intArrayOf(128)), 0.5)
        assertEquals(150.0, Pids.all[Pids.FUEL_RAIL]!!.decode(intArrayOf(0x05, 0xDC)), 0.01) // 1500/10 bar
    }

    // ---- Diagnostics ----
    @Test fun overheatIsCritical() {
        val f = Diagnostics.analyze(mapOf(Pids.COOLANT to 112.0, Pids.RPM to 900.0), 14.0)
        assertEquals(Severity.CRIT, f.first().severity)
    }

    @Test fun healthyReadingsGiveNoFindings() {
        val f = Diagnostics.analyze(
            mapOf(Pids.COOLANT to 90.0, Pids.RPM to 900.0, Pids.LOAD to 30.0, Pids.SPEED to 0.0), 14.2)
        assertTrue(f.isEmpty())
    }

    @Test fun weakChargingDetected() {
        val f = Diagnostics.analyze(mapOf(Pids.RPM to 1500.0), 12.4)
        assertTrue(f.any { it.title.contains("الدينامو") })
    }

    @Test fun leanTrimDetected() {
        val f = Diagnostics.analyze(mapOf(Pids.RPM to 1500.0, Pids.LTFT to 22.0), 14.0)
        assertTrue(f.any { it.title.contains("فقير") })
    }

    // ---- Boost ----
    @Test fun boostRules() {
        assertNull(Boost.finding(false, 100.0, 100.0))
        assertNull(Boost.finding(true, null, 100.0))
        assertNotNull(Boost.finding(true, 110.0, 100.0))
        assertNull(Boost.finding(true, 160.0, 100.0))
        // الضغط الجوي المنخفض (ارتفاع) يخفّض العتبة
        assertNull(Boost.finding(true, 125.0, 90.0))
        assertNotNull(Boost.finding(true, 120.0, 90.0))
    }

    // ---- Deep analyzer ----
    @Test fun recentClearExplainedWhenNoCodes() {
        val v = DeepAnalyzer.verdicts(emptyList(), emptyList(), emptyList(),
            mapOf("kmClear" to 80), null, emptyList(), false, null)
        assertTrue(v.any { it.title.contains("حديث المسح") })
    }

    @Test fun storedCodeProducesVerdictWithCauses() {
        val v = DeepAnalyzer.verdicts(listOf("P0299"), emptyList(), null,
            emptyMap(), null, emptyList(), true, 150.0, 100.0)
        assertTrue(v.first().title.contains("P0299"))
    }

    @Test fun incompleteMonitorsReported() {
        val r = Readiness(false, 0, listOf("المكونات الشاملة" to false))
        val v = DeepAnalyzer.verdicts(emptyList(), emptyList(), emptyList(),
            mapOf("kmClear" to 5000), r, emptyList(), false, null)
        assertTrue(v.any { it.title.contains("غير مكتملة") })
    }

    @Test fun cleanCarGetsReassuringVerdict() {
        val v = DeepAnalyzer.verdicts(emptyList(), emptyList(), emptyList(),
            mapOf("kmClear" to 9000), Readiness(false, 0, emptyList()), emptyList(), false, null)
        assertTrue(v.single().title.contains("على أعطال"))
    }

    // ---- Trips ----
    @Test fun tripSummaryIntegratesDistanceAndFuel() {
        val f = File.createTempFile("trip", ".csv")
        try {
            val sb = StringBuilder("time_ms,rpm,speed_kmh,coolant_c,load_pct,throttle_pct,fuel_lph,voltage\n")
            for (i in 0..4) sb.append("${i * 5000L},2000,72,90,40,20,3.6,14.0\n")
            f.writeText(sb.toString())
            val t = TripStore.summarize(f)!!
            assertEquals(0.4, t.distanceKm, 0.001)
            assertEquals(0.02, t.fuelLiters, 0.001)
            assertEquals(72.0, t.avgSpeed, 0.01)
            assertEquals(20, t.durationSec)
        } finally { f.delete() }
    }

    // ---- Transport ----
    private class MemTransport(data: String) : StreamTransport() {
        init { input = ByteArrayInputStream(data.toByteArray()); output = ByteArrayOutputStream() }
        override suspend fun open() {}
        override fun close() {}
    }

    @Test fun transportStopsAtPrompt() = runBlocking {
        val t = MemTransport("41 0C 1A F8\r\r>")
        assertEquals("41 0C 1A F8\r\r", t.readUntilPrompt(500))
    }

    @Test fun transportTimesOutWhenSilent() {
        val t = MemTransport("")
        try {
            runBlocking { t.readUntilPrompt(100) }
            fail("كان يجب أن ترمي ObdException")
        } catch (e: ObdException) {
            assertTrue(e.message!!.isNotEmpty())
        }
    }
}
