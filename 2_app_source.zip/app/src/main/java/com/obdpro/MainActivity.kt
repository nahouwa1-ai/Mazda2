package com.obdpro

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.obdpro.ui.ConnectScreen
import com.obdpro.ui.DashboardScreen
import com.obdpro.ui.FaultsScreen
import com.obdpro.ui.ObdTheme
import com.obdpro.ui.Pal
import com.obdpro.ui.TripsScreen

class MainActivity : ComponentActivity() {
    private val vm: ObdEngine by lazy { ObdEngine.get(application) }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                ObdTheme { App(vm) }
            }
        }
    }
}

private class Tab(val title: String, val icon: ImageVector)

@androidx.compose.runtime.Composable
private fun App(vm: ObdEngine) {
    val s by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf(
        Tab("القيادة", Icons.Filled.Home),
        Tab("الأعطال", Icons.Filled.Warning),
        Tab("الرحلات", Icons.Filled.Menu),
        Tab("الاتصال", Icons.Filled.Settings)
    )
    LaunchedEffect(tab) { if (tab == 2) vm.refreshTrips() }

    Scaffold(
        containerColor = Pal.Bg,
        bottomBar = {
            NavigationBar(containerColor = Pal.Panel) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.title) },
                        label = { Text(t.title) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Pal.Bg, selectedTextColor = Pal.Ice,
                            indicatorColor = Pal.Ice, unselectedIconColor = Pal.Dim, unselectedTextColor = Pal.Dim
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                0 -> DashboardScreen(s, onDismissAlert = { vm.dismissAlert() })
                1 -> FaultsScreen(s, onRead = { vm.readFaults() }, onClear = { vm.clearFaults() }, onDeep = { vm.deepScan() }, getLog = { vm.logText() })
                2 -> TripsScreen(s, onShare = { vm.shareTrip(it) }, onDelete = { vm.deleteTrip(it) })
                else -> ConnectScreen(s, vm)
            }
        }
    }
}
