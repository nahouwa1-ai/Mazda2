package com.obdpro.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.delay
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID

/** قناة اتصال خام مع محوّل ELM327. */
interface ObdTransport {
    suspend fun open()
    fun close()
    suspend fun write(command: String)
    /** يقرأ حتى ظهور محرف '>' (جاهزية المحوّل) أو انتهاء المهلة. */
    suspend fun readUntilPrompt(timeoutMs: Long): String
}

/** أساس مشترك للقنوات المبنية على InputStream/OutputStream. */
abstract class StreamTransport : ObdTransport {
    protected var input: InputStream? = null
    protected var output: OutputStream? = null

    override suspend fun write(command: String) {
        val out = output ?: throw ObdException("الاتصال مغلق")
        // تفريغ أي بقايا قديمة قبل إرسال أمر جديد
        val inp = input
        while (inp != null && inp.available() > 0) inp.read()
        out.write((command + "\r").toByteArray())
        out.flush()
    }

    override suspend fun readUntilPrompt(timeoutMs: Long): String {
        val inp = input ?: throw ObdException("الاتصال مغلق")
        val sb = StringBuilder()
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (inp.available() > 0) {
                val c = inp.read()
                if (c < 0) throw ObdException("أُغلق الاتصال من المحوّل")
                if (c.toChar() == '>') return sb.toString()
                sb.append(c.toChar())
            } else {
                delay(8)
            }
        }
        if (sb.isEmpty()) throw ObdException("انتهت مهلة الاستجابة")
        return sb.toString()
    }
}

class BluetoothTransport(private val device: BluetoothDevice) : StreamTransport() {
    private var socket: BluetoothSocket? = null

    @SuppressLint("MissingPermission")
    override suspend fun open() {
        val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        var s: BluetoothSocket? = null
        try {
            s = device.createRfcommSocketToServiceRecord(sppUuid)
            s.connect()
        } catch (e: Exception) {
            // بعض المحوّلات الرخيصة تحتاج هذه الطريقة البديلة
            try {
                s?.close()
                val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                s = m.invoke(device, 1) as BluetoothSocket
                s.connect()
            } catch (e2: Exception) {
                try { s?.close() } catch (_: Exception) {}
                throw ObdException("تعذّر الاتصال بالمحوّل: ${e2.message ?: e.message}")
            }
        }
        socket = s
        input = s!!.inputStream
        output = s.outputStream
    }

    override fun close() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null; input = null; output = null
    }
}

class WifiTransport(private val host: String, private val port: Int) : StreamTransport() {
    private var socket: Socket? = null

    override suspend fun open() {
        try {
            val s = Socket()
            s.connect(InetSocketAddress(host, port), 5000)
            s.tcpNoDelay = true
            socket = s
            input = s.getInputStream()
            output = s.getOutputStream()
        } catch (e: Exception) {
            throw ObdException("تعذّر الاتصال بـ $host:$port — تأكد من الاتصال بشبكة المحوّل")
        }
    }

    override fun close() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null; input = null; output = null
    }
}

class ObdException(message: String) : Exception(message)
