package com.obdpro.obd

/** تعريف قراءة حيّة واحدة (Mode 01). */
class PidDef(
    val pid: Int,
    val name: String,
    val unit: String,
    val bytes: Int,
    val decode: (IntArray) -> Double
)

object Pids {
    const val LOAD = 0x04
    const val COOLANT = 0x05
    const val STFT = 0x06
    const val LTFT = 0x07
    const val MAP = 0x0B
    const val RPM = 0x0C
    const val SPEED = 0x0D
    const val TIMING = 0x0E
    const val IAT = 0x0F
    const val MAF = 0x10
    const val THROTTLE = 0x11
    const val RUNTIME = 0x1F
    const val FUEL_LEVEL = 0x2F
    const val BARO = 0x33
    const val MODULE_V = 0x42
    const val AMBIENT = 0x46
    const val FUEL_RAIL = 0x23
    const val CAT_TEMP = 0x3C
    const val PEDAL = 0x49
    const val OIL_TEMP = 0x5C
    const val FUEL_RATE = 0x5E
    /** قراءة الجهد عبر ATRV وليست PID حقيقية. */
    const val BATTERY = 0x1000

    val all: Map<Int, PidDef> = listOf(
        PidDef(LOAD, "حمل المحرك", "%", 1) { it[0] * 100.0 / 255 },
        PidDef(COOLANT, "حرارة التبريد", "°C", 1) { it[0] - 40.0 },
        PidDef(STFT, "تصحيح الوقود قصير", "%", 1) { it[0] * 100.0 / 128 - 100 },
        PidDef(LTFT, "تصحيح الوقود طويل", "%", 1) { it[0] * 100.0 / 128 - 100 },
        PidDef(MAP, "ضغط المشعب", "kPa", 1) { it[0].toDouble() },
        PidDef(RPM, "الدورات", "rpm", 2) { (256.0 * it[0] + it[1]) / 4 },
        PidDef(SPEED, "السرعة", "km/h", 1) { it[0].toDouble() },
        PidDef(TIMING, "توقيت الإشعال", "°", 1) { it[0] / 2.0 - 64 },
        PidDef(IAT, "حرارة الهواء", "°C", 1) { it[0] - 40.0 },
        PidDef(MAF, "تدفق الهواء", "g/s", 2) { (256.0 * it[0] + it[1]) / 100 },
        PidDef(THROTTLE, "الخانق", "%", 1) { it[0] * 100.0 / 255 },
        PidDef(RUNTIME, "زمن التشغيل", "s", 2) { 256.0 * it[0] + it[1] },
        PidDef(FUEL_LEVEL, "مستوى الوقود", "%", 1) { it[0] * 100.0 / 255 },
        PidDef(BARO, "الضغط الجوي", "kPa", 1) { it[0].toDouble() },
        PidDef(MODULE_V, "جهد الوحدة", "V", 2) { (256.0 * it[0] + it[1]) / 1000 },
        PidDef(AMBIENT, "حرارة الجو", "°C", 1) { it[0] - 40.0 },
        PidDef(FUEL_RAIL, "ضغط سكة الوقود", "bar", 2) { (256.0 * it[0] + it[1]) / 10 },
        PidDef(CAT_TEMP, "حرارة المحفز", "°C", 2) { (256.0 * it[0] + it[1]) / 10 - 40 },
        PidDef(PEDAL, "دواسة الوقود", "%", 1) { it[0] * 100.0 / 255 },
        PidDef(OIL_TEMP, "حرارة الزيت", "°C", 1) { it[0] - 40.0 },
        PidDef(FUEL_RATE, "معدل الوقود", "L/h", 2) { (256.0 * it[0] + it[1]) / 20 }
    ).associateBy { it.pid }

    /** قراءات سريعة تُستعلم في كل دورة. */
    val fast = listOf(RPM, SPEED, THROTTLE, LOAD)
    /** قراءات بطيئة تُدار بالتناوب. */
    val slow = listOf(
        COOLANT, MAF, STFT, LTFT, IAT, MAP, TIMING, FUEL_LEVEL,
        OIL_TEMP, FUEL_RATE, MODULE_V, AMBIENT, BARO, RUNTIME, FUEL_RAIL, PEDAL, CAT_TEMP
    )
}
