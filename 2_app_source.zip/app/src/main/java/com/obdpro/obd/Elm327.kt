package com.obdpro.obd

class Readiness(val milOn: Boolean, val dtcCount: Int, val monitors: List<Pair<String, Boolean>>)
/** كل مراقب: الاسم، وهل اكتمل فحصه. المراقبات غير المدعومة لا تُدرج. */

class Elm327(private val t: ObdTransport, private val onLog: (String) -> Unit = {}) {
    var protocolNumber: String = "0"
        private set
    var adapterName: String = ""
        private set

    private val isCan get() = protocolNumber.firstOrNull() in '6'..'9'

    suspend fun initialize() {
        val reset = rawLines("ATZ", 3000).joinToString(" ")
        adapterName = Regex("ELM327V?[0-9.]*").find(reset)?.value?.replace("V", " v") ?: "ELM327 (متوافق)"
        for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATAT1", "ATSP0")) rawLines(c, 1500)
    }

    /** يكتشف البروتوكول بعد أول استعلام ناجح. */
    suspend fun detectProtocol() {
        val p = rawLines("ATDPN", 1500).firstOrNull()?.removePrefix("A") ?: "0"
        protocolNumber = p
    }

    // ---------- أدوات خام ----------

    private fun clean(s: String): List<String> =
        s.split('\r', '\n').map { it.replace(" ", "").uppercase() }
            .filter { it.isNotEmpty() && !it.startsWith("SEARCHING") && !it.startsWith("BUSINIT") }

    private suspend fun rawLines(cmd: String, timeout: Long = 2500, quiet: Boolean = false): List<String> {
        val raw = try {
            t.write(cmd)
            t.readUntilPrompt(timeout)
        } catch (e: ObdException) {
            if (!quiet) onLog("→ $cmd\n✗ ${e.message}")
            throw e
        }
        if (!quiet) onLog("→ $cmd\n← " + raw.replace("\r", "⏎").replace("\n", "↵").trim())
        return clean(raw)
    }

    private fun isError(l: List<String>) =
        l.isEmpty() || l.any {
            it.contains("NODATA") || it.contains("UNABLE") || it.contains("ERROR") ||
                it.contains("STOPPED") || it.contains("CANERROR") || it == "?"
        }

    /** يحوّل سطر HEX إلى بايتات. */
    private fun bytesOf(line: String): List<Int> =
        line.chunked(2).mapNotNull { if (it.length == 2) it.toIntOrNull(16) else null }

    /** يجمع الإطارات المتعددة (ISO-TP) في رسائل منطقية. */
    private fun messages(lines: List<String>): List<List<Int>> {
        val out = mutableListOf<MutableList<Int>>()
        for (l in lines) {
            when {
                Regex("^[0-9A-F]:.*").matches(l) -> out.lastOrNull()?.addAll(bytesOf(l.substring(2)))
                Regex("^[0-9A-F]{3}$").matches(l) -> out += mutableListOf<Int>() // ترويسة الطول
                else -> out += bytesOf(l).toMutableList()
            }
        }
        return out.filter { it.isNotEmpty() }
    }

    // ---------- Mode 01 ----------

    suspend fun readBatteryVoltage(): Double? {
        val l = rawLines("ATRV", 1500, quiet = true).firstOrNull() ?: return null
        return l.removeSuffix("V").toDoubleOrNull()
    }

    suspend fun supportedPids(): Set<Int> {
        val set = mutableSetOf<Int>()
        var base = 0x00
        while (base <= 0xA0) {
            val data = query(0x01, base, 4, if (base == 0) 15000 else 3000) ?: break
            val v = (data[0].toLong() shl 24) or (data[1].toLong() shl 16) or (data[2].toLong() shl 8) or data[3].toLong()
            for (i in 0 until 32) if ((v shr (31 - i)) and 1L == 1L) set += base + i + 1
            if (!set.contains(base + 0x20)) break
            base += 0x20
        }
        return set
    }

    /** يرجع بايتات البيانات لـ mode/pid أو null عند الفشل. */
    suspend fun query(mode: Int, pid: Int, expected: Int, timeout: Long = 2500, log: Boolean = true): IntArray? {
        val cmd = "%02X%02X".format(mode, pid)
        val lines = rawLines(cmd, timeout, quiet = !log)
        if (isError(lines)) return null
        val head = listOf(0x40 + mode, pid)
        for (m in messages(lines)) {
            if (m.size >= 2 + expected && m[0] == head[0] && m[1] == head[1]) {
                return m.subList(2, 2 + expected).toIntArray()
            }
        }
        return null
    }

    suspend fun readPid(def: PidDef): Double? =
        query(0x01, def.pid, def.bytes, log = false)?.let { def.decode(it) }

    suspend fun readiness(): Readiness? {
        val d = query(0x01, 0x01, 4) ?: return null
        val a = d[0]; val b = d[1]; val c = d[2]; val dd = d[3]
        val mons = mutableListOf<Pair<String, Boolean>>()
        val names = listOf("الاحتراق الخاطئ", "نظام الوقود", "المكونات الشاملة")
        for (i in 0..2) if ((b shr i) and 1 == 1) mons += names[i] to (((b shr (4 + i)) and 1) == 0)
        val diesel = (b shr 3) and 1 == 1
        val cNames = if (!diesel)
            listOf("المحفز", "المحفز المسخّن", "نظام EVAP", "الهواء الثانوي", "مكيف الهواء", "حساس الأكسجين", "سخّان الأكسجين", "نظام EGR")
        else
            listOf("NMHC", "NOx/SCR", "", "ضغط الشاحن", "", "حساس العادم", "فلتر الجسيمات", "EGR/VVT")
        for (i in 0..7) if (cNames[i].isNotEmpty() && (c shr i) and 1 == 1) {
            mons += cNames[i] to (((dd shr i) and 1) == 0)
        }
        return Readiness((a and 0x80) != 0, a and 0x7F, mons)
    }

    // ---------- الأعطال ----------

    private suspend fun readCodes(cmd: String, resp: Int): List<String>? {
        val lines = rawLines(cmd, 4000)
        if (lines.any { it.contains("NODATA") }) return emptyList()
        if (isError(lines)) return null
        val codes = mutableListOf<String>()
        for (m in messages(lines)) {
            if (m.isEmpty() || m[0] != resp) continue
            var payload = m.drop(1)
            if (isCan && payload.isNotEmpty()) payload = payload.drop(1) // بايت العدد
            codes += Dtc.parsePairs(payload)
        }
        onLog("نتيجة $cmd: " + (if (codes.isEmpty()) "لا أكواد" else codes.distinct().joinToString(" ")))
        return codes.distinct()
    }

    suspend fun permanentCodes() = readCodes("0A", 0x4A)

    suspend fun storedCodes() = readCodes("03", 0x43)
    suspend fun pendingCodes() = readCodes("07", 0x47)

    suspend fun clearCodes(): Boolean {
        val lines = rawLines("04", 4000)
        return lines.any { it.startsWith("44") }
    }

    /** لقطة تجميد الإطار لمجموعة قراءات. */
    suspend fun freezeFrame(): Map<String, String> {
        val out = linkedMapOf<String, String>()
        val dtc = rawLines("020200")
        messages(dtc).firstOrNull { it.size >= 5 && it[0] == 0x42 && it[1] == 0x02 }?.let {
            out["العطل المسبب"] = Dtc.decode(it[3], it[4])
        }
        for (pid in listOf(Pids.RPM, Pids.SPEED, Pids.COOLANT, Pids.LOAD, Pids.STFT, Pids.LTFT)) {
            val def = Pids.all[pid] ?: continue
            val lines = rawLines("02%02X00".format(pid))
            if (isError(lines)) continue
            val m = messages(lines).firstOrNull { it.size >= 3 + def.bytes && it[0] == 0x42 && it[1] == pid } ?: continue
            val v = def.decode(m.subList(3, 3 + def.bytes).toIntArray())
            out[def.name] = "%.0f %s".format(v, def.unit)
        }
        return out
    }

    /** عدّادات: مسافة وزمن منذ آخر مسح ومع المصباح مضاءً. */
    suspend fun counters(): Map<String, Int> {
        val out = linkedMapOf<String, Int>()
        for ((pid, key) in listOf(0x21 to "kmMil", 0x31 to "kmClear", 0x4D to "minMil", 0x4E to "minClear")) {
            val d = try { query(0x01, pid, 2) } catch (e: ObdException) { null }
            if (d != null) out[key] = d[0] * 256 + d[1]
        }
        val w = try { query(0x01, 0x30, 1) } catch (e: ObdException) { null }
        if (w != null) out["warmups"] = w[0]
        return out
    }

    /** نصوص Mode 09 (مثل 0A اسم الوحدة، 04 رقم المعايرة). */
    suspend fun infoText(pid: Int): String? {
        val lines = try { rawLines("09%02X".format(pid), 4000) } catch (e: ObdException) { return null }
        if (isError(lines)) return null
        val sb = StringBuilder()
        for (m in messages(lines)) {
            if (m.size > 3 && m[0] == 0x49 && m[1] == pid) {
                m.drop(3).forEach { if (it in 0x20..0x7E) sb.append(it.toChar()) }
            }
        }
        return sb.toString().trim().takeIf { it.length >= 3 }
    }

    /** معرّفات الاختبارات الذاتية المدعومة (Mode 06). */
    suspend fun mode06Supported(): List<Int> {
        val mids = mutableSetOf<Int>()
        var base = 0x00
        while (base <= 0xA0) {
            val lines = try { rawLines("06%02X".format(base), 4000) } catch (e: ObdException) { break }
            if (isError(lines)) break
            val m = messages(lines).firstOrNull { it.size >= 6 && it[0] == 0x46 && it[1] == base } ?: break
            val v = (m[2].toLong() shl 24) or (m[3].toLong() shl 16) or (m[4].toLong() shl 8) or m[5].toLong()
            for (i in 0 until 32) if ((v shr (31 - i)) and 1L == 1L) mids += base + i + 1
            if (!mids.contains(base + 0x20)) break
            base += 0x20
        }
        return mids.filter { it % 0x20 != 0 }.sorted()
    }

    suspend fun mode06Read(mid: Int): List<TestResult> {
        val out = mutableListOf<TestResult>()
        val lines = rawLines("06%02X".format(mid), 4000)
        if (isError(lines)) return out
        for (m in messages(lines)) {
            if (m.size < 10 || m[0] != 0x46 || m[1] != mid) continue
            var i = 2
            while (i + 8 <= m.size) {
                out += TestResult(mid, m[i], (m[i + 2] shl 8) or m[i + 3], (m[i + 4] shl 8) or m[i + 5], (m[i + 6] shl 8) or m[i + 7])
                i += 8
            }
        }
        return out
    }

    suspend fun vin(): String? {
        val lines = rawLines("0902", 4000)
        if (isError(lines)) return null
        val sb = StringBuilder()
        for (m in messages(lines)) {
            if (m.size > 3 && m[0] == 0x49 && m[1] == 0x02) {
                m.drop(3).forEach { if (it in 0x30..0x5A) sb.append(it.toChar()) }
            }
        }
        return sb.toString().takeIf { it.length >= 11 }
    }
}
