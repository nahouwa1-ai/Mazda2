package com.obdpro.obd

class Finding(val severity: Severity, val title: String, val detail: String, val advice: String)

/** محرك قواعد يحلل القراءات الحيّة ويكتشف الأنماط المشبوهة. */
object Diagnostics {
    fun analyze(v: Map<Int, Double>, battery: Double?): List<Finding> {
        val out = mutableListOf<Finding>()
        val rpm = v[Pids.RPM]
        val running = rpm != null && rpm > 400

        v[Pids.COOLANT]?.let {
            if (it >= 108) out += Finding(Severity.CRIT, "ارتفاع خطير في حرارة المحرك",
                "حرارة التبريد %.0f°م".format(it),
                "أوقف السيارة بأمان وأطفئ المحرك. افحص مستوى التبريد والمروحة. لا تفتح غطاء الرادياتير وهو ساخن.")
            else if (it >= 100) out += Finding(Severity.WARN, "حرارة المحرك مرتفعة",
                "حرارة التبريد %.0f°م".format(it), "قلّل الحمل وراقب العداد. افحص مستوى التبريد والمروحة.")
            else if (running && it < 70 && (v[Pids.RUNTIME] ?: 0.0) > 900)
                out += Finding(Severity.INFO, "المحرك لا يصل لحرارة التشغيل",
                    "%.0f°م بعد أكثر من 15 دقيقة".format(it), "غالبًا الثرموستات عالق مفتوحًا.")
        }

        v[Pids.OIL_TEMP]?.let {
            if (it >= 140) out += Finding(Severity.CRIT, "حرارة الزيت مرتفعة جدًا",
                "%.0f°م".format(it), "خفّف القيادة فورًا وافحص مستوى الزيت.")
            else if (it >= 125) out += Finding(Severity.WARN, "حرارة الزيت مرتفعة", "%.0f°م".format(it),
                "قلّل الحمل على المحرك.")
        }

        if (battery != null) {
            if (running && battery < 13.0) out += Finding(
                if (battery < 12.2) Severity.CRIT else Severity.WARN,
                "الدينامو لا يشحن بشكل كافٍ", "الجهد %.1f فولت والمحرك يعمل".format(battery),
                "افحص سير الدينامو والدينامو والبطارية.")
            else if (battery > 15.0) out += Finding(Severity.WARN, "جهد شحن مرتفع",
                "%.1f فولت".format(battery), "غالبًا عطل في منظّم الدينامو.")
            else if (!running && battery < 12.0) out += Finding(Severity.WARN, "البطارية ضعيفة",
                "%.1f فولت والمحرك مطفأ".format(battery), "اشحن البطارية أو افحصها، قد تحتاج استبدالًا.")
        }

        val ltft = v[Pids.LTFT]; val stft = v[Pids.STFT]
        if (ltft != null && running) {
            if (ltft > 15) out += Finding(Severity.WARN, "خليط فقير مستمر",
                "التصحيح الطويل +%.0f%%".format(ltft),
                "الأسباب المرجّحة: تسريب هواء، حساس MAF متسخ، ضغط وقود ضعيف.")
            else if (ltft < -15) out += Finding(Severity.WARN, "خليط غني مستمر",
                "التصحيح الطويل %.0f%%".format(ltft),
                "الأسباب المرجّحة: بخاخ يسرّب، فلتر هواء مسدود، حساس MAF.")
        }
        if (stft != null && running && kotlin.math.abs(stft) > 20)
            out += Finding(Severity.INFO, "تذبذب في تصحيح الوقود", "قصير الأمد %.0f%%".format(stft),
                "راقب القراءة. استمرارها يدل على مشكلة في الهواء أو الوقود.")

        val load = v[Pids.LOAD]; val thr = v[Pids.THROTTLE]
        if (rpm != null && load != null && rpm in 500.0..1100.0 && (v[Pids.SPEED] ?: 0.0) < 2 && load > 55)
            out += Finding(Severity.WARN, "حمل مرتفع عند الدوران الخامل", "الحمل %.0f%%".format(load),
                "قد يدل على تسريب تفريغ أو جسم خانق متسخ أو احتراق خاطئ.")

        v[Pids.IAT]?.let {
            if (it > 65 && running) out += Finding(Severity.INFO, "حرارة هواء الدخول مرتفعة",
                "%.0f°م".format(it), "افحص مجرى الهواء وفلتر الهواء. الحرارة العالية تقلل القدرة.")
        }

        if (rpm != null && rpm > 6000)
            out += Finding(Severity.INFO, "دورات محرك عالية جدًا", "%.0f rpm".format(rpm), "خفّف السرعة أو بدّل الترس.")

        if (thr != null && load != null && thr > 80 && load < 25 && running)
            out += Finding(Severity.WARN, "حمل منخفض رغم فتح الخانق",
                "خانق %.0f%% وحمل %.0f%%".format(thr, load), "قد يدل على اختناق في السحب أو عطل بحساس.")

        return out.sortedByDescending { it.severity.ordinal }
    }
}
