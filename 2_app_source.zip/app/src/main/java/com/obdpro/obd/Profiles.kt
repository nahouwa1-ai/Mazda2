package com.obdpro.obd

class VehicleProfile(val name: String, val diesel: Boolean, val turbo: Boolean)

/** ملفات سيارات معروفة تُطبَّق تلقائيًا عند التعرف على الـVIN. */
object VehicleProfiles {
    fun match(vin: String?): VehicleProfile? {
        val v = vin?.uppercase() ?: return null
        return when {
            v.startsWith("JMZCR19T") -> VehicleProfile("مازدا 5 ديزل 2.0 (محرك RF)", diesel = true, turbo = true)
            else -> null
        }
    }
}
