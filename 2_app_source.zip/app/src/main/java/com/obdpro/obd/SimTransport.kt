package com.obdpro.obd

import kotlin.math.abs
import kotlin.math.sin

/**
 * محاكي ELM327 كامل لتجربة التطبيق بدون سيارة.
 * يمرّ عبر نفس مسار التحليل الحقيقي (Elm327 → Pids → Dtc).
 */
class SimTransport : ObdTransport {
    private var pending = ""
    private var t0 = System.currentTimeMillis()
    private var cleared = false

    override suspend fun open() { t0 = System.currentTimeMillis() }
    override fun close() {}

    override suspend fun write(command: String) {
        pending = respond(command.trim().uppercase().replace(" ", ""))
    }

    override suspend fun readUntilPrompt(timeoutMs: Long): String {
        kotlinx.coroutines.delay(25)
        return pending
    }

    private fun sec() = (System.currentTimeMillis() - t0) / 1000.0

    private fun bitmap(base: Int, supported: Set<Int>): String {
        var v = 0L
        for (p in supported) {
            val idx = p - base - 1
            if (idx in 0..31) v = v or (1L shl (31 - idx))
        }
        return "%08X".format(v).chunked(2).joinToString(" ")
    }

    private fun hex2(v: Int) = "%02X".format(v and 0xFF)

    private fun respond(c: String): String {
        val s = sec()
        val rpm = (850 + 2400 * abs(sin(s / 7.0))).toInt()
        val speed = (70 * abs(sin(s / 11.0))).toInt()
        return when {
            c == "ATZ" -> "ELM327 v1.5"
            c.startsWith("AT") && c != "ATRV" && c != "ATDPN" -> "OK"
            c == "ATRV" -> if (rpm > 500) "14.1V" else "12.6V"
            c == "ATDPN" -> "A6"
            c == "0100" -> "41 00 " + bitmap(0, setOf(4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 31, 32))
            c == "0120" -> "41 20 " + bitmap(0x20, setOf(0x2F, 0x33, 0x40))
            c == "0140" -> "41 40 " + bitmap(0x40, setOf(0x42, 0x46, 0x5C))
            c == "010C" -> { val r = rpm * 4; "41 0C ${hex2(r shr 8)} ${hex2(r)}" }
            c == "010D" -> "41 0D ${hex2(speed)}"
            c == "0105" -> "41 05 ${hex2(40 + 88 + (6 * sin(s / 30.0)).toInt())}"
            c == "0104" -> "41 04 ${hex2((255 * (0.25 + 0.3 * abs(sin(s / 7.0)))).toInt())}"
            c == "0111" -> "41 11 ${hex2((255 * (0.15 + 0.35 * abs(sin(s / 7.0)))).toInt())}"
            c == "010F" -> "41 0F ${hex2(40 + 32)}"
            c == "0110" -> { val m = (200 + rpm * 0.35).toInt(); "41 10 ${hex2(m shr 8)} ${hex2(m)}" }
            c == "0106" -> "41 06 ${hex2(128 + 3)}"
            c == "0107" -> "41 07 ${hex2(128 + 21)}"
            c == "010B" -> "41 0B ${hex2(35 + speed / 3)}"
            c == "010E" -> "41 0E ${hex2(128 + 22)}"
            c == "012F" -> "41 2F ${hex2(140)}"
            c == "0133" -> "41 33 65"
            c == "011F" -> { val r = sec().toInt(); "41 1F ${hex2(r shr 8)} ${hex2(r)}" }
            c == "0142" -> "41 42 36 B0"
            c == "0146" -> "41 46 ${hex2(40 + 24)}"
            c == "015C" -> "41 5C ${hex2(40 + 95)}"
            c == "0101" -> if (cleared) "41 01 00 07 E5 00" else "41 01 82 07 E5 20"
            c == "03" -> if (cleared) "43 00" else "43 02 01 71 03 00 00"
            c == "07" -> if (cleared) "47 00" else "47 01 04 20 00 00 00"
            c == "04" -> { cleared = true; "44" }
            c == "0A" -> "4A 00"
            c == "0121" -> "41 21 00 14"
            c == "0131" -> "41 31 00 50"
            c == "014D" -> "41 4D 00 0A"
            c == "014E" -> "41 4E 00 32"
            c == "0600" -> "46 00 " + bitmap(0, setOf(0x01, 0x20))
            c == "0620" -> "46 20 " + bitmap(0x20, setOf(0x21))
            c == "0601" -> "46 01 02 8E 00 64 00 50 00 C8"
            c == "0621" -> "46 21 01 0C 02 00 00 00 01 00"
            c == "0902" -> "014\r0: 49 02 01 57 56 57\r1: 5A 5A 5A 31 4B 5A 41\r2: 4D 36 39 35 30 31 32"
            c.startsWith("02") && c.length >= 4 -> when (c.substring(2, 4)) {
                "02" -> if (cleared) "NO DATA" else "42 02 00 01 71"
                "0C" -> "42 0C 00 1B 58"
                "0D" -> "42 0D 00 2D"
                "05" -> "42 05 00 80"
                "04" -> "42 04 00 5A"
                "06" -> "42 06 00 9A"
                "07" -> "42 07 00 8E"
                else -> "NO DATA"
            }
            else -> "NO DATA"
        }
    }
}
