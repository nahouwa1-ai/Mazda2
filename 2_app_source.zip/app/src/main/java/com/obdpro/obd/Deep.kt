package com.obdpro.obd

/** نتيجة اختبار مراقبة ذاتية (Mode 06). */
class TestResult(val mid: Int, val tid: Int, val value: Int, val min: Int, val max: Int) {
    val failed: Boolean get() = max != 0 && (value > max || value < min)

    val name: String
        get() = when (mid) {
            in 0x01..0x08 -> "حساس الأكسجين"
            0x21 -> "المحفز (بنك 1)"
            0x22 -> "المحفز (بنك 2)"
            0xA0 -> "الاحتراق الخاطئ (عام)"
            in 0xA1..0xA8 -> "الاحتراق الخاطئ (أسطوانة ${mid - 0xA0})"
            in 0x80..0x9F -> "اختبار خاص بالشركة (0x%02X)".format(mid)
            else -> "اختبار ذاتي 0x%02X".format(mid)
        }
}

/** تقرير الفحص العميق. */
class DeepReport(
    val vin: String?,
    val ecu: String?,
    val calId: String?,
    val stored: List<String>?,
    val pending: List<String>?,
    val permanent: List<String>?,
    val counters: Map<String, Int>,
    val readiness: Readiness?,
    val freeze: Map<String, String>,
    val tests: List<TestResult>,
    val verdicts: List<Finding>
) {
    fun toText(): String {
        val sb = StringBuilder()
        sb.appendLine("تقرير الفحص العميق — ObdPro")
        vin?.let { sb.appendLine("VIN: $it") }
        ecu?.let { sb.appendLine("وحدة التحكم: $it") }
        calId?.let { sb.appendLine("المعايرة: $it") }
        fun codes(title: String, l: List<String>?) {
            sb.appendLine()
            if (l == null) sb.appendLine("$title: تعذّرت القراءة")
            else if (l.isEmpty()) sb.appendLine("$title: لا توجد")
            else { sb.appendLine("$title:"); l.forEach { sb.appendLine("  $it — ${Dtc.lookup(it).title}") } }
        }
        codes("الأعطال المخزّنة", stored)
        codes("الأعطال المعلّقة", pending)
        codes("الأعطال الدائمة", permanent)
        sb.appendLine()
        counters["kmClear"]?.let { sb.appendLine("المسافة منذ آخر مسح: $it كم") }
        counters["minClear"]?.let { sb.appendLine("زمن التشغيل منذ آخر مسح: $it دقيقة") }
        counters["kmMil"]?.let { sb.appendLine("المسافة والمصباح مضاء: $it كم") }
        counters["warmups"]?.let { sb.appendLine("دورات التسخين منذ آخر مسح: $it") }
        readiness?.let { r ->
            sb.appendLine("المصباح: " + (if (r.milOn) "مضاء" else "مطفأ"))
            r.monitors.forEach { sb.appendLine("  ${it.first}: " + (if (it.second) "مكتمل" else "غير مكتمل")) }
        }
        if (freeze.isNotEmpty()) { sb.appendLine(); sb.appendLine("لقطة التجميد:"); freeze.forEach { sb.appendLine("  ${it.key}: ${it.value}") } }
        if (tests.isNotEmpty()) {
            sb.appendLine(); sb.appendLine("الاختبارات الذاتية: ${tests.size} (خارج الحدود: ${tests.count { it.failed }})")
            tests.filter { it.failed }.forEach { sb.appendLine("  ${it.name}: القيمة ${it.value} (الحدود ${it.min}–${it.max})") }
        }
        sb.appendLine(); sb.appendLine("الخلاصة:")
        verdicts.forEach { sb.appendLine("  [${it.severity.label}] ${it.title} — ${it.detail}") }
        return sb.toString()
    }
}

object DeepAnalyzer {
    fun verdicts(
        stored: List<String>?, pending: List<String>?, permanent: List<String>?,
        counters: Map<String, Int>, readiness: Readiness?, tests: List<TestResult>,
        turbo: Boolean, boostPeak: Double?, baro: Double? = null
    ): List<Finding> {
        val out = mutableListOf<Finding>()
        fun addCodes(l: List<String>?, prefix: String) {
            l?.forEach {
                val i = Dtc.lookup(it)
                out += Finding(i.severity, "$prefix$it — ${i.title}", "الأسباب المحتملة: " + i.causes.joinToString("، "), i.advice)
            }
        }
        addCodes(stored, "")
        addCodes(pending, "(قيد المراقبة) ")
        if (!permanent.isNullOrEmpty()) out += Finding(Severity.WARN, "أعطال دائمة: " + permanent.joinToString(" "),
            "لا تُمسح بالجهاز.", "تختفي وحدها بعد إصلاح السبب وإكمال دورات قيادة ناجحة.")

        val noCodes = stored.isNullOrEmpty() && pending.isNullOrEmpty() && permanent.isNullOrEmpty()
        val sinceClear = counters["kmClear"]
        if (noCodes && sinceClear != null && sinceClear < 160) out += Finding(Severity.INFO,
            "سجل الأعطال حديث المسح",
            "آخر مسح قبل $sinceClear كم فقط.",
            "الأعطال المتقطعة قد لا تُسجَّل بعد. قُد دورتين أو ثلاثًا كاملة (تسخين ثم سرعة طريق) ثم أعد الفحص.")

        if (readiness != null) {
            val inc = readiness.monitors.filter { !it.second }.map { it.first }
            if (inc.isNotEmpty()) out += Finding(Severity.INFO, "فحوصات ذاتية غير مكتملة",
                inc.joinToString("، "), "غياب الأعطال لا يعني سلامة هذه الأنظمة بعد. تكتمل بالقيادة المتنوعة.")
            if (readiness.milOn && noCodes) out += Finding(Severity.WARN, "المصباح مضاء بلا أكواد مقروءة",
                "عدد الأعطال المعلنة ${readiness.dtcCount}.", "قد يكون العطل خاصًّا بالماركة أو في وحدة أخرى. يلزم جهاز يدعم ماركتك.")
        }

        val failing = tests.filter { it.failed }
        if (failing.isNotEmpty()) out += Finding(Severity.WARN, "${failing.size} اختبار ذاتي خارج الحدود",
            failing.take(4).joinToString("، ") { it.name },
            "مؤشر مبكر على مكوّن ضعيف حتى قبل ظهور كود. تفسير الأرقام يختلف حسب الماركة.")

        Boost.finding(turbo, boostPeak, baro)?.let { out += it }
        if (turbo && boostPeak == null) out += Finding(Severity.INFO, "ضغط الشاحن لم يُختبر بعد",
            "لم يحدث تسارع قوي أثناء الاتصال.", "سرّع بقوة من 1800 دورة فأكثر أثناء الاتصال ثم أعد الفحص.")

        if (out.isEmpty()) out += Finding(Severity.INFO, "لم يُعثر على أعطال في الفحص القياسي",
            "السيارة لم تُبلغ عن أعطال محرك أو انبعاثات.", "الفحص لا يغطي الفرامل والوسائد والناقل في أغلب الماركات.")
        return out.sortedByDescending { it.severity.ordinal }
    }
}

object Boost {
    /** أقل زيادة متوقعة فوق الضغط الجوي عند حمل عالٍ في محرك بشاحن. */
    const val MIN_BOOST_KPA = 35.0

    fun finding(turbo: Boolean, peak: Double?, baro: Double? = null): Finding? {
        if (!turbo || peak == null) return null
        val need = (baro ?: 100.0) + MIN_BOOST_KPA
        return if (peak < need)
            Finding(Severity.WARN, "الشاحن لا يعطي ضغطًا كافيًا",
                "أعلى ضغط مشعب عند الحمل العالي %.0f kPa (المتوقع %.0f أو أكثر)".format(peak, need),
                "يوافق عطل P0299: افحص خراطيم الشاحن والمبرّد الهوائي وصمام VNT. الرقم تقريبي ويتأثر بالارتفاع عن البحر.")
        else null
    }
}
