package com.obdpro.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** لوحة ألوان "غرفة العدادات": أزرق فولاذي داكن مع كهرمان تحذيري. */
object Pal {
    val Bg = Color(0xFF0E141B)
    val Panel = Color(0xFF16202B)
    val PanelHi = Color(0xFF1E2B3A)
    val Line = Color(0xFF2D3E52)
    val Ice = Color(0xFF7FD6FF)
    val Amber = Color(0xFFFFB020)
    val Red = Color(0xFFFF5A4F)
    val Green = Color(0xFF52D68A)
    val Text = Color(0xFFE6EDF5)
    val Dim = Color(0xFF8FA3B8)
}

private val scheme = darkColorScheme(
    primary = Pal.Ice, onPrimary = Pal.Bg,
    secondary = Pal.Amber, background = Pal.Bg, onBackground = Pal.Text,
    surface = Pal.Panel, onSurface = Pal.Text, error = Pal.Red,
    surfaceVariant = Pal.PanelHi, onSurfaceVariant = Pal.Dim, outline = Pal.Line
)

private val typo = Typography(
    headlineMedium = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelSmall = TextStyle(fontSize = 11.sp)
)

/** خط رقمي ثابت العرض لأرقام العدادات. */
val DigitFont = FontFamily.Monospace

@Composable
fun ObdTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typo, content = content)
}
