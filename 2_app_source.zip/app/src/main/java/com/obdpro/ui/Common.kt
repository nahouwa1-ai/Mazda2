package com.obdpro.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.obdpro.obd.Severity

fun sevColor(s: Severity): Color = when (s) {
    Severity.CRIT -> Pal.Red
    Severity.WARN -> Pal.Amber
    Severity.INFO -> Pal.Ice
}

/** حاوية لوحة موحّدة. */
@Composable
fun Panel(modifier: Modifier = Modifier, accent: Color? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .background(Pal.Panel, RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, accent ?: Pal.Line), RoundedCornerShape(12.dp))
            .padding(14.dp),
        content = content
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = Pal.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
}

@Composable
fun Chip(text: String, color: Color) {
    Box(
        Modifier.background(color.copy(alpha = 0.16f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
}

/** يعزل النص كاتجاه يسار-يمين حتى لا تنقلب الأرقام والوحدات في الواجهة العربية. */
fun ltr(s: String): String = "\u2066" + s + "\u2069"

fun protocolName(n: String): String = when (n.firstOrNull()) {
    '1' -> "SAE J1850 PWM"
    '2' -> "SAE J1850 VPW"
    '3' -> "ISO 9141-2"
    '4' -> "ISO 14230-4 (KWP 5 baud)"
    '5' -> "ISO 14230-4 (KWP سريع)"
    '6' -> "CAN 11 بت / 500 كب"
    '7' -> "CAN 29 بت / 500 كب"
    '8' -> "CAN 11 بت / 250 كب"
    '9' -> "CAN 29 بت / 250 كب"
    else -> "تلقائي"
}

fun fmtDuration(sec: Int): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
