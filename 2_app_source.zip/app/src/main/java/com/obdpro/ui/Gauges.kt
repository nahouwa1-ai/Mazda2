package com.obdpro.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

/** عدّاد قوسي بزاوية 240° مع تدريج وقيمة رقمية في المنتصف. */
@Composable
fun ArcGauge(
    value: Double?,
    min: Double,
    max: Double,
    label: String,
    unit: String,
    modifier: Modifier = Modifier,
    redFrom: Double? = null,
    decimals: Int = 0,
    ticks: Int = 8
) {
    val frac = if (value == null) 0f else ((value - min) / (max - min)).toFloat().coerceIn(0f, 1f)
    val anim by animateFloatAsState(frac, tween(250), label = "gauge")
    val inRed = redFrom != null && value != null && value >= redFrom
    val barColor = if (inRed) Pal.Red else Pal.Ice

    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxWidth().aspectRatio(1f).padding(10.dp)) {
            val stroke = size.minDimension * 0.07f
            val inset = stroke / 2 + 4f
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val tl = Offset(inset, inset)
            val start = 150f
            val sweep = 240f
            drawArc(Pal.PanelHi, start, sweep, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            if (redFrom != null) {
                val rf = ((redFrom - min) / (max - min)).toFloat().coerceIn(0f, 1f)
                drawArc(Pal.Red.copy(alpha = 0.35f), start + sweep * rf, sweep * (1 - rf), false, tl, arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Butt))
            }
            if (anim > 0.002f) {
                drawArc(barColor, start, sweep * anim, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            // علامات التدريج
            val cx = size.width / 2; val cy = size.height / 2
            val rOuter = size.minDimension / 2 - inset - stroke * 0.9f
            val rInner = rOuter - stroke * 0.55f
            for (i in 0..ticks) {
                val a = Math.toRadians((start + sweep * i / ticks).toDouble())
                drawLine(Pal.Dim, Offset(cx + (rInner * cos(a)).toFloat(), cy + (rInner * sin(a)).toFloat()),
                    Offset(cx + (rOuter * cos(a)).toFloat(), cy + (rOuter * sin(a)).toFloat()),
                    strokeWidth = if (i % 2 == 0) 3f else 1.5f)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                if (value == null) "--" else "%.${decimals}f".format(value),
                color = if (inRed) Pal.Red else Pal.Text,
                fontFamily = DigitFont, fontWeight = FontWeight.Bold, fontSize = 40.sp
            )
            Text(unit, color = Pal.Dim, fontSize = 13.sp)
            Text(label, color = Pal.Ice, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** بلاطة قراءة صغيرة مع شريط تعبئة سفلي. */
@Composable
fun StatTile(
    label: String,
    value: Double?,
    unit: String,
    modifier: Modifier = Modifier,
    decimals: Int = 0,
    min: Double? = null,
    max: Double? = null,
    warnAbove: Double? = null,
    critAbove: Double? = null
) {
    val color = when {
        value == null -> Pal.Dim
        critAbove != null && value >= critAbove -> Pal.Red
        warnAbove != null && value >= warnAbove -> Pal.Amber
        else -> Pal.Text
    }
    Column(
        modifier
            .background(Pal.Panel, RoundedCornerShape(10.dp))
            .border(1.dp, Pal.Line, RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Text(label, color = Pal.Dim, fontSize = 12.sp)
        Text(
            ltr(if (value == null) "--" else "%.${decimals}f".format(value) + " $unit"),
            color = color, fontFamily = DigitFont, fontWeight = FontWeight.Bold, fontSize = 20.sp,
            modifier = Modifier.padding(top = 4.dp)
        )
        if (min != null && max != null) {
            val f = if (value == null) 0f else ((value - min) / (max - min)).toFloat().coerceIn(0f, 1f)
            Box(Modifier.padding(top = 8.dp).fillMaxWidth().height(4.dp).background(Pal.PanelHi, RoundedCornerShape(2.dp))) {
                Box(Modifier.fillMaxWidth(f).height(4.dp).background(if (color == Pal.Text) Pal.Ice else color, RoundedCornerShape(2.dp)))
            }
        }
    }
}
