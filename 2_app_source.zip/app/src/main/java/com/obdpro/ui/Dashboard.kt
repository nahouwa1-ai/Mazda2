package com.obdpro.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.obdpro.ConnState
import com.obdpro.UiState
import com.obdpro.obd.Pids
import com.obdpro.obd.Severity

private class Tile(
    val pid: Int, val label: String, val value: Double?, val unit: String,
    val decimals: Int = 0, val min: Double? = null, val max: Double? = null,
    val warn: Double? = null, val crit: Double? = null
)

private fun kmhToUnit(v: Double?, imp: Boolean) = if (imp && v != null) v * 0.621371 else v
private fun cToUnit(v: Double?, imp: Boolean) = if (imp && v != null) v * 9 / 5 + 32 else v

@Composable
fun DashboardScreen(s: UiState, onDismissAlert: () -> Unit) {
    val imp = s.imperial
    val speedUnit = if (imp) "mph" else "km/h"
    val tUnit = if (imp) "°F" else "°C"
    val v = s.live

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        s.alert?.let { msg ->
            Panel(accent = Pal.Red) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(msg, color = Pal.Red, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismissAlert) { Text("إخفاء", color = Pal.Dim) }
                }
            }
        }

        // شريط الحالة
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            val dot = when (s.conn) {
                ConnState.CONNECTED -> Pal.Green
                ConnState.CONNECTING -> Pal.Amber
                ConnState.DISCONNECTED -> Pal.Red
            }
            Box(Modifier.size(10.dp).background(dot, CircleShape))
            Spacer(Modifier.width(8.dp))
            Text(if (s.simulated && s.conn == ConnState.CONNECTED) "متصل (محاكاة)" else s.message,
                color = Pal.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
            val bat = s.battery ?: v[Pids.MODULE_V]
            if (bat != null) {
                Text(ltr("%.1f V".format(bat)), color = if (bat < 12.0 || bat > 15.0) Pal.Amber else Pal.Ice,
                    fontFamily = DigitFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }

        // العدادان الرئيسيان
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ArcGauge(v[Pids.RPM], 0.0, 8000.0, "الدورات", "rpm", Modifier.weight(1f), redFrom = 6500.0)
            ArcGauge(kmhToUnit(v[Pids.SPEED], imp), 0.0, if (imp) 160.0 else 240.0, "السرعة", speedUnit, Modifier.weight(1f))
        }

        // الحالة الذكية
        val top = s.findings.firstOrNull()
        Panel(accent = top?.let { sevColor(it.severity) }) {
            if (s.conn != ConnState.CONNECTED) {
                Text("اتصل بالسيارة لبدء الفحص الحي", color = Pal.Dim, fontSize = 14.sp)
            } else if (s.findings.isEmpty()) {
                Text("القراءات ضمن الحدود الطبيعية", color = Pal.Green, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            } else {
                s.findings.take(3).forEachIndexed { i, f ->
                    if (i > 0) Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Chip(f.severity.label, sevColor(f.severity))
                        Spacer(Modifier.width(8.dp))
                        Text(f.title, color = Pal.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    }
                    Text(f.detail, color = Pal.Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
                    Text(f.advice, color = Pal.Text, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
                }
            }
        }

        // البلاطات: تُعرض فقط القراءات التي تدعمها السيارة
        val tiles = listOf(
            Tile(Pids.COOLANT, "حرارة التبريد", cToUnit(v[Pids.COOLANT], imp), tUnit,
                min = cToUnit(0.0, imp), max = cToUnit(130.0, imp), warn = cToUnit(100.0, imp), crit = cToUnit(108.0, imp)),
            Tile(Pids.LOAD, "حمل المحرك", v[Pids.LOAD], "%", min = 0.0, max = 100.0),
            Tile(Pids.PEDAL, "دواسة الوقود", v[Pids.PEDAL], "%", min = 0.0, max = 100.0),
            Tile(Pids.THROTTLE, "الخانق", v[Pids.THROTTLE], "%", min = 0.0, max = 100.0),
            Tile(Pids.MAP, "ضغط المشعب", v[Pids.MAP], "kPa"),
            Tile(Pids.BARO, "الضغط الجوي", v[Pids.BARO], "kPa"),
            Tile(Pids.MAF, "تدفق الهواء MAF", v[Pids.MAF], "g/s", decimals = 1),
            Tile(Pids.FUEL_RAIL, "ضغط سكة الوقود", v[Pids.FUEL_RAIL], "bar", min = 0.0, max = 2000.0),
            Tile(Pids.IAT, "حرارة الهواء", cToUnit(v[Pids.IAT], imp), tUnit, warn = cToUnit(65.0, imp)),
            Tile(Pids.CAT_TEMP, "حرارة المحفز", cToUnit(v[Pids.CAT_TEMP], imp), tUnit),
            Tile(Pids.OIL_TEMP, "حرارة الزيت", cToUnit(v[Pids.OIL_TEMP], imp), tUnit,
                warn = cToUnit(125.0, imp), crit = cToUnit(140.0, imp)),
            Tile(Pids.STFT, "تصحيح وقود قصير", v[Pids.STFT], "%", decimals = 1),
            Tile(Pids.LTFT, "تصحيح وقود طويل", v[Pids.LTFT], "%", decimals = 1),
            Tile(Pids.FUEL_LEVEL, "مستوى الوقود", v[Pids.FUEL_LEVEL], "%", min = 0.0, max = 100.0),
            Tile(Pids.TIMING, "توقيت الإشعال", v[Pids.TIMING], "°", decimals = 1),
            Tile(-1, "استهلاك لحظي", s.fuelLph, "L/h", decimals = 1)
        )
        val core = setOf(Pids.COOLANT, Pids.LOAD, Pids.THROTTLE, Pids.MAP, Pids.MAF, Pids.IAT)
        val visible = tiles.filter {
            if (it.pid == -1) s.fuelLph != null
            else if (s.supported.isEmpty()) it.pid in core
            else it.pid in s.supported
        }
        visible.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { t ->
                    StatTile(t.label, t.value, t.unit, Modifier.weight(1f), t.decimals, t.min, t.max, t.warn, t.crit)
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        if (s.turbo) {
            Panel {
                Text("ضغط الشاحن", color = Pal.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(
                    s.boostPeakKpa?.let { ltr("أعلى ضغط مشعب عند الحمل العالي: %.0f kPa".format(it)) }
                        ?: "لم يُختبر بعد: سرّع بقوة من 1800 دورة فأكثر.",
                    color = Pal.Dim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // الرحلة الحالية
        Panel {
            Text("الرحلة الحالية", color = Pal.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(8.dp))
            val dist = if (imp) s.tripKm * 0.621371 else s.tripKm
            val distUnit = if (imp) "mi" else "km"
            val l100 = if (s.tripKm > 0.3) s.tripLiters / s.tripKm * 100 else null
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TripStat("المسافة", "%.1f %s".format(dist, distUnit))
                TripStat("المدة", fmtDuration(s.tripSeconds))
                TripStat("الاستهلاك", l100?.let { "%.1f L/100".format(it) } ?: "--")
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun TripStat(label: String, value: String) {
    Column {
        Text(label, color = Pal.Dim, fontSize = 12.sp)
        Text(ltr(value), color = Pal.Text, fontFamily = DigitFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}
