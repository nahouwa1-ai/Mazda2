package com.obdpro.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.obdpro.UiState
import com.obdpro.data.TripSummary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TripsScreen(s: UiState, onShare: (TripSummary) -> Unit, onDelete: (TripSummary) -> Unit) {
    val fmt = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US)
    val imp = s.imperial
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (s.trips.isEmpty()) {
            Panel {
                Text("لا توجد رحلات مسجّلة", color = Pal.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text("تُسجَّل الرحلة تلقائيًا عند الاتصال بالسيارة وتشغيل المحرك، وتظهر هنا بعد فصل الاتصال.",
                    color = Pal.Dim, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
        s.trips.forEach { t ->
            Panel {
                Text(fmt.format(Date(t.startMillis)), color = Pal.Ice, fontFamily = DigitFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                val k = if (imp) 0.621371 else 1.0
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Cell("المسافة", "%.1f %s".format(t.distanceKm * k, if (imp) "mi" else "km"))
                    Cell("المدة", fmtDuration(t.durationSec))
                    Cell("الاستهلاك", t.lPer100?.let { "%.1f L/100".format(it) } ?: "--")
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Cell("متوسط السرعة", "%.0f".format(t.avgSpeed * k))
                    Cell("أقصى سرعة", "%.0f".format(t.maxSpeed * k))
                    Cell("أقصى دورات", "%.0f".format(t.maxRpm))
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { onShare(t) }) { Text("تصدير CSV", color = Pal.Ice) }
                    TextButton(onClick = { onDelete(t) }) { Text("حذف", color = Pal.Red) }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun Cell(label: String, value: String) {
    Column {
        Text(label, color = Pal.Dim, fontSize = 12.sp)
        Text(ltr(value), color = Pal.Text, fontFamily = DigitFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}
