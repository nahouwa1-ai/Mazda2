package com.obdpro.ui

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.obdpro.ConnState
import com.obdpro.ObdEngine
import com.obdpro.UiState

private fun hasBtPermission(c: Context) =
    Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(c, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

@SuppressLint("MissingPermission")
private fun nameOf(d: BluetoothDevice): String = try { d.name ?: d.address } catch (e: SecurityException) { d.address }

@Composable
fun ConnectScreen(s: UiState, vm: ObdEngine) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasBtPermission(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasBtPermission(ctx)
    }
    var host by remember { mutableStateOf(vm.wifiHost) }
    var port by remember { mutableStateOf(vm.wifiPort.toString()) }
    val idle = s.conn == ConnState.DISCONNECTED

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Panel(accent = when (s.conn) {
            ConnState.CONNECTED -> Pal.Green
            ConnState.CONNECTING -> Pal.Amber
            else -> null
        }) {
            Text(s.message, color = Pal.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            if (s.conn != ConnState.DISCONNECTED) {
                Spacer(Modifier.height(10.dp))
                Button(onClick = { vm.disconnect() }, colors = ButtonDefaults.buttonColors(containerColor = Pal.Red)) {
                    Text("قطع الاتصال")
                }
            }
        }

        if (idle) {
            SectionTitle("بلوتوث")
            if (!granted) {
                Panel {
                    Text("يحتاج التطبيق إذن الأجهزة القريبة لرؤية محوّل OBD المقترن.", color = Pal.Dim, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { launcher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT)) }) { Text("منح الإذن") }
                }
            } else {
                val devices = remember(granted, s.conn) { vm.bondedDevices() }
                if (devices.isEmpty()) {
                    Text("لا توجد أجهزة مقترنة. اقرن المحوّل أولًا من إعدادات بلوتوث الهاتف (الرمز غالبًا 1234 أو 0000).",
                        color = Pal.Dim, fontSize = 13.sp)
                }
                devices.forEach { d ->
                    Panel(Modifier.clickable { vm.connectBluetooth(d.address) }) {
                        Text(nameOf(d), color = Pal.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(d.address, color = Pal.Dim, fontFamily = DigitFont, fontSize = 12.sp)
                    }
                }
            }

            SectionTitle("واي فاي")
            Panel {
                OutlinedTextField(host, { host = it }, label = { Text("العنوان") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("المنفذ") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Button(onClick = { vm.connectWifi(host.trim(), port.toIntOrNull() ?: 35000) }) { Text("اتصال") }
            }

            SectionTitle("بدون سيارة")
            Panel {
                Text("وضع المحاكاة يشغّل محوّلًا افتراضيًا لتجربة كل الشاشات.", color = Pal.Dim, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.connectSimulator() }) { Text("تشغيل المحاكاة", color = Pal.Ice) }
            }
        }

        SectionTitle("الإعدادات")
        Panel {
            SwitchRow("وحدات إنجليزية (mph / °F)", s.imperial) { vm.setImperial(it) }
            HorizontalDivider(color = Pal.Line, modifier = Modifier.padding(vertical = 6.dp))
            SwitchRow("محرك ديزل (لتقدير الاستهلاك)", s.diesel) { vm.setDiesel(it) }
            HorizontalDivider(color = Pal.Line, modifier = Modifier.padding(vertical = 6.dp))
            SwitchRow("محرك بشاحن توربيني (لفحص الضغط)", s.turbo) { vm.setTurbo(it) }
            HorizontalDivider(color = Pal.Line, modifier = Modifier.padding(vertical = 6.dp))
            SwitchRow("إعادة الاتصال تلقائيًا عند الانقطاع", s.autoReconnect) { vm.setAutoReconnect(it) }
        }
        Text("الاستهلاك تقديري من حساس MAF ما لم تعرضه السيارة مباشرة.", color = Pal.Dim, fontSize = 11.sp)

        s.notice?.let {
            AlertDialog(
                onDismissRequest = { vm.dismissNotice() },
                confirmButton = { TextButton(onClick = { vm.dismissNotice() }) { Text("حسنًا") } },
                text = { Text(it) }
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Pal.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(value, onChange)
    }
}
