package com.obdpro.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.LayoutDirection
import com.obdpro.ConnState
import com.obdpro.UiState
import com.obdpro.obd.DeepReport
import com.obdpro.obd.Dtc

@Composable
fun FaultsScreen(s: UiState, onRead: () -> Unit, onClear: () -> Unit, onDeep: () -> Unit, getLog: () -> String) {
    var confirm by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    val connected = s.conn == ConnState.CONNECTED

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("مسح الأعطال؟") },
            text = { Text("سيُطفأ مصباح المحرك وتُمسح لقطة التجميد وجاهزية الفحص. إن بقي السبب ستعود الأعطال. لا تمسحها قبل تسجيلها.") },
            confirmButton = { TextButton(onClick = { confirm = false; onClear() }) { Text("امسح", color = Pal.Red) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
        )
    }

    if (showLog) {
        val text = remember(showLog) { getLog() }
        val clip = LocalClipboardManager.current
        AlertDialog(
            onDismissRequest = { showLog = false },
            title = { Text("سجل الاتصال") },
            text = {
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            if (text.isEmpty()) "No log yet. Connect, then tap read faults." else text,
                            fontFamily = DigitFont, fontSize = 11.sp, color = Pal.Text
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { clip.setText(AnnotatedString(text)) }) { Text("نسخ") } },
            dismissButton = { TextButton(onClick = { showLog = false }) { Text("إغلاق") } }
        )
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onRead, enabled = connected && s.busy == null, modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Pal.Ice, contentColor = Pal.Bg)) {
                Text("قراءة الأعطال", fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = { confirm = true }, enabled = connected && s.busy == null && !s.stored.isNullOrEmpty(),
                modifier = Modifier.weight(1f)) { Text("مسح الأعطال", color = if (connected) Pal.Amber else Pal.Dim) }
        }
        Button(onClick = onDeep, enabled = connected && s.busy == null, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Pal.Amber, contentColor = Pal.Bg)) {
            Text("فحص عميق شامل", fontWeight = FontWeight.Bold)
        }
        TextButton(onClick = { showLog = true }) { Text("عرض سجل الاتصال (للتشخيص)", color = Pal.Ice) }
        if (s.faultsRead && s.stored == null) {
            Panel(accent = Pal.Red) {
                Text("تعذّرت قراءة الأعطال المخزّنة. افتح سجل الاتصال وانسخه وأرسله.", color = Pal.Red, fontSize = 14.sp)
            }
        }
        if (s.faultsRead && s.pending == null) {
            Panel(accent = Pal.Amber) {
                Text("تعذّرت قراءة الأعطال المعلّقة (قيد المراقبة).", color = Pal.Amber, fontSize = 14.sp)
            }
        }
        if (s.busy != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Pal.Ice)
                Spacer(Modifier.width(10.dp))
                Text(s.busy, color = Pal.Dim)
            }
        }
        if (!connected) Text("اتصل بالسيارة من تبويب الاتصال لقراءة الأعطال.", color = Pal.Dim, fontSize = 14.sp)

        s.deep?.let { DeepSection(it) }

        s.readiness?.let { r ->
            Panel(accent = if (r.milOn) Pal.Amber else null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("مصباح المحرك", color = Pal.Dim, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    if (r.milOn) Chip("مضاء — ${r.dtcCount} عطل", Pal.Amber) else Chip("مطفأ", Pal.Green)
                }
            }
        }

        s.stored?.let { codes ->
            SectionTitle("الأعطال المخزّنة")
            if (codes.isEmpty()) Panel { Text("لا توجد أعطال مخزّنة", color = Pal.Green, fontWeight = FontWeight.SemiBold) }
            else codes.forEach { DtcCard(it) }
        }

        s.pending?.let { codes ->
            if (codes.isNotEmpty()) {
                SectionTitle("أعطال قيد المراقبة")
                Text("لم تتأكد بعد وقد تتحول لأعطال مخزّنة.", color = Pal.Dim, fontSize = 12.sp)
                codes.forEach { DtcCard(it) }
            }
        }

        if (s.freeze.isNotEmpty()) {
            SectionTitle("لقطة لحظة العطل")
            Panel {
                s.freeze.entries.forEachIndexed { i, (k, v) ->
                    if (i > 0) HorizontalDivider(color = Pal.Line, modifier = Modifier.padding(vertical = 6.dp))
                    Row {
                        Text(k, color = Pal.Dim, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text(ltr(v), color = Pal.Text, fontFamily = DigitFont, fontSize = 13.sp)
                    }
                }
            }
        }

        s.readiness?.let { r ->
            if (r.monitors.isNotEmpty()) {
                SectionTitle("جاهزية الفحص الدوري")
                Panel {
                    r.monitors.forEachIndexed { i, (name, done) ->
                        if (i > 0) HorizontalDivider(color = Pal.Line, modifier = Modifier.padding(vertical = 6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(name, color = Pal.Text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            if (done) Chip("مكتمل", Pal.Green) else Chip("غير مكتمل", Pal.Amber)
                        }
                    }
                }
            }
        }

        if (connected) {
            SectionTitle("معلومات السيارة")
            Panel {
                s.vehicleName?.let { InfoRow("السيارة", it) }
                InfoRow("الهيكل VIN", s.vin ?: "غير متاح")
                InfoRow("البروتوكول", protocolName(s.protocol))
                InfoRow("المحوّل", s.adapter.ifEmpty { "ELM327" })
                InfoRow("القراءات المدعومة", "${s.supportedCount}")
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun DeepSection(r: DeepReport) {
    val clip = LocalClipboardManager.current
    SectionTitle("نتيجة الفحص العميق")
    r.verdicts.forEach { f ->
        Panel(accent = sevColor(f.severity)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Chip(f.severity.label, sevColor(f.severity))
                Spacer(Modifier.width(8.dp))
                Text(f.title, color = Pal.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            }
            Text(f.detail, color = Pal.Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            Text(f.advice, color = Pal.Text, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
    if (r.counters.isNotEmpty() || r.tests.isNotEmpty() || r.ecu != null || r.calId != null) {
        Panel {
            r.counters["kmClear"]?.let { InfoRow("المسافة منذ آخر مسح", "$it km") }
            r.counters["minClear"]?.let { InfoRow("زمن التشغيل منذ آخر مسح", "$it min") }
            r.counters["kmMil"]?.let { InfoRow("المسافة والمصباح مضاء", "$it km") }
            r.counters["warmups"]?.let { InfoRow("دورات التسخين منذ المسح", "$it") }
            if (r.tests.isNotEmpty()) {
                InfoRow("الاختبارات الذاتية", "${r.tests.size}")
                InfoRow("خارج الحدود", "${r.tests.count { it.failed }}")
            }
            r.ecu?.let { InfoRow("وحدة التحكم", it) }
            r.calId?.let { InfoRow("المعايرة", it) }
        }
    }
    OutlinedButton(onClick = { clip.setText(AnnotatedString(r.toText())) }) { Text("نسخ التقرير", color = Pal.Ice) }
}

@Composable
private fun InfoRow(k: String, v: String) {
    Row(Modifier.padding(vertical = 3.dp)) {
        Text(k, color = Pal.Dim, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(ltr(v), color = Pal.Text, fontFamily = DigitFont, fontSize = 13.sp)
    }
}

@Composable
private fun DtcCard(code: String) {
    val info = remember(code) { Dtc.lookup(code) }
    var open by remember { mutableStateOf(false) }
    Panel(Modifier.clickable { open = !open }, accent = sevColor(info.severity)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(code, color = sevColor(info.severity), fontFamily = DigitFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(Modifier.width(10.dp))
            Chip(info.severity.label, sevColor(info.severity))
        }
        Text(info.title, color = Pal.Text, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
        if (open) {
            Text("الأسباب المحتملة", color = Pal.Ice, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 10.dp))
            info.causes.forEach { Text("• $it", color = Pal.Dim, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp)) }
            Text("ما العمل", color = Pal.Ice, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 10.dp))
            Text(info.advice, color = Pal.Text, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        } else {
            Text("اضغط للتفاصيل", color = Pal.Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
