package com.obdpro

import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.obdpro.data.Settings
import com.obdpro.data.TripRecorder
import com.obdpro.data.TripStore
import com.obdpro.data.TripSummary
import com.obdpro.obd.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.coroutineContext

enum class ConnState { DISCONNECTED, CONNECTING, CONNECTED }

data class UiState(
    val conn: ConnState = ConnState.DISCONNECTED,
    val message: String = "غير متصل",
    val adapter: String = "",
    val protocol: String = "",
    val vin: String? = null,
    val vehicleName: String? = null,
    val supported: Set<Int> = emptySet(),
    val supportedCount: Int = 0,
    val live: Map<Int, Double> = emptyMap(),
    val battery: Double? = null,
    val fuelLph: Double? = null,
    val findings: List<Finding> = emptyList(),
    val stored: List<String>? = null,
    val pending: List<String>? = null,
    val readiness: Readiness? = null,
    val freeze: Map<String, String> = emptyMap(),
    val busy: String? = null,
    val notice: String? = null,
    val tripKm: Double = 0.0,
    val tripLiters: Double = 0.0,
    val tripSeconds: Int = 0,
    val imperial: Boolean = false,
    val diesel: Boolean = false,
    val turbo: Boolean = false,
    val autoReconnect: Boolean = true,
    val trips: List<TripSummary> = emptyList(),
    val simulated: Boolean = false,
    val faultsRead: Boolean = false,
    val boostPeakKpa: Double? = null,
    val alert: String? = null,
    val deep: DeepReport? = null
)

private class SessionResult(val connected: Boolean, val error: String?)

/**
 * محرك التطبيق: يعيش بعيدًا عن الشاشة، فيستمر الاتصال والتسجيل
 * حين يُغلق التطبيق أو تنطفئ الشاشة (بمساعدة ObdService).
 */
class ObdEngine private constructor(private val app: Application) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val settings = Settings(app)
    private val recorder = TripRecorder(app)
    private val mutex = Mutex()
    private var job: Job? = null
    @Volatile private var elm: Elm327? = null
    private var tripSecD = 0.0
    @Volatile private var boostPeak: Double? = null
    private val logBuf = java.util.ArrayDeque<String>()

    @Synchronized private fun addLog(s: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        logBuf.addLast("[$t] $s")
        while (logBuf.size > 500) logBuf.removeFirst()
    }

    @Synchronized fun logText(): String = logBuf.joinToString("\n")

    private val _state = MutableStateFlow(
        UiState(imperial = settings.imperial, diesel = settings.diesel, turbo = settings.turbo,
            autoReconnect = settings.autoReconnect)
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    val wifiHost get() = settings.wifiHost
    val wifiPort get() = settings.wifiPort

    init { refreshTrips() }

    companion object {
        private const val MAX_RETRIES = 40
        private const val RETRY_DELAY_MS = 5000L
        @Volatile private var instance: ObdEngine? = null

        fun get(app: Application): ObdEngine =
            instance ?: synchronized(this) { instance ?: ObdEngine(app).also { instance = it } }
    }

    // ---------- الاتصال ----------

    @SuppressLint("MissingPermission")
    fun bondedDevices(): List<BluetoothDevice> = try {
        val mgr = app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        mgr.adapter?.bondedDevices?.toList() ?: emptyList()
    } catch (e: SecurityException) {
        emptyList()
    }

    @SuppressLint("MissingPermission")
    fun connectBluetooth(address: String) {
        settings.lastBtAddress = address
        start("بلوتوث", false) {
            val mgr = app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val dev = mgr.adapter?.getRemoteDevice(address) ?: throw ObdException("البلوتوث غير متاح")
            BluetoothTransport(dev)
        }
    }

    fun connectWifi(host: String, port: Int) {
        settings.wifiHost = host; settings.wifiPort = port
        start("واي فاي", false) { WifiTransport(host, port) }
    }

    fun connectSimulator() = start("محاكاة", true) { SimTransport() }

    private fun startService() {
        try {
            ContextCompat.startForegroundService(app, Intent(app, ObdService::class.java))
        } catch (e: Exception) {
            addLog("تعذّر تشغيل خدمة الخلفية: ${e.message}")
        }
    }

    private fun stopService() {
        try { app.stopService(Intent(app, ObdService::class.java)) } catch (_: Exception) {}
    }

    private fun start(label: String, sim: Boolean, factory: () -> ObdTransport) {
        if (_state.value.conn != ConnState.DISCONNECTED) return
        tripSecD = 0.0
        boostPeak = null
        synchronized(this) { logBuf.clear() }
        addLog("بدء الاتصال ($label)")
        _state.update {
            UiState(conn = ConnState.CONNECTING, message = "جارٍ الاتصال ($label)…",
                imperial = it.imperial, diesel = it.diesel, turbo = it.turbo,
                autoReconnect = it.autoReconnect, trips = it.trips, simulated = sim)
        }
        startService()
        job = scope.launch {
            var everConnected = false
            var attempt = 0
            var finalMsg: String? = null
            try {
                while (isActive) {
                    val r = runSession(factory)
                    if (r.connected) { everConnected = true; attempt = 0 }
                    val canRetry = settings.autoReconnect && everConnected
                    if (!canRetry || attempt >= MAX_RETRIES) { finalMsg = r.error; break }
                    attempt++
                    addLog("إعادة الاتصال $attempt/$MAX_RETRIES")
                    _state.update {
                        it.copy(conn = ConnState.CONNECTING, live = emptyMap(), battery = null, fuelLph = null,
                            message = "انقطع الاتصال. إعادة المحاولة ($attempt/$MAX_RETRIES)…")
                    }
                    delay(RETRY_DELAY_MS)
                }
            } finally {
                recorder.stop()
                stopService()
                _state.update {
                    it.copy(conn = ConnState.DISCONNECTED, message = finalMsg ?: "غير متصل",
                        live = emptyMap(), fuelLph = null, battery = null, busy = null)
                }
                refreshTrips()
            }
        }
    }

    /** جلسة اتصال واحدة: تهيئة ثم قراءة حيّة حتى الانقطاع. */
    private suspend fun runSession(factory: () -> ObdTransport): SessionResult {
        var transport: ObdTransport? = null
        var connected = false
        try {
            transport = factory()
            transport.open()
            val e = Elm327(transport) { addLog(it) }
            e.initialize()
            _state.update { it.copy(message = "جارٍ البحث عن السيارة… شغّل الإشعال") }
            val supported = e.supportedPids()
            if (supported.isEmpty()) throw ObdException("لا توجد استجابة من السيارة. شغّل الإشعال وأعد المحاولة.")
            e.detectProtocol()
            val vin = try { e.vin() } catch (_: ObdException) { null }
            elm = e
            connected = true

            val profile = VehicleProfiles.match(vin)
            if (profile != null && vin != null && settings.profileVin != vin) {
                settings.diesel = profile.diesel
                settings.turbo = profile.turbo
                settings.profileVin = vin
                addLog("طُبّق ملف السيارة: ${profile.name}")
            }
            _state.update {
                it.copy(conn = ConnState.CONNECTED, message = "متصل", adapter = e.adapterName,
                    protocol = e.protocolNumber, vin = vin, vehicleName = profile?.name,
                    supported = supported, supportedCount = supported.size,
                    diesel = settings.diesel, turbo = settings.turbo)
            }
            pollLoop(e, supported)
            return SessionResult(true, null)
        } catch (c: CancellationException) {
            throw c
        } catch (x: Exception) {
            val msg = x.message ?: "خطأ غير معروف"
            addLog("خطأ: $msg")
            return SessionResult(connected, msg)
        } finally {
            elm = null
            transport?.close()
        }
    }

    fun disconnect() {
        job?.cancel()
    }

    // ---------- القراءة الحيّة ----------

    private suspend fun pollLoop(e: Elm327, supported: Set<Int>) {
        val fast = Pids.fast.filter { it in supported }
        val slow = Pids.slow.filter { it in supported }
        var slowIdx = 0
        var cycle = 0
        var failures = 0
        var lastTick = System.currentTimeMillis()
        var battery: Double? = null
        val live = HashMap<Int, Double>()
        var lastDtc = System.currentTimeMillis()
        val seen = mutableSetOf<String>()

        while (coroutineContext.isActive) {
            val list = fast.toMutableList()
            if (slow.isNotEmpty()) list += slow[slowIdx++ % slow.size]
            var ok = false
            for (pid in list) {
                val def = Pids.all[pid] ?: continue
                try {
                    val v = mutex.withLock { e.readPid(def) }
                    if (v != null) { live[pid] = v; ok = true }
                } catch (x: ObdException) {
                    // تُحتسب كفشل في هذه الدورة
                }
            }
            if (cycle % 8 == 0) {
                try { mutex.withLock { e.readBatteryVoltage() }?.let { battery = it; ok = true } } catch (_: ObdException) {}
            }
            cycle++
            if (ok) failures = 0 else if (++failures >= 5) throw ObdException("انقطع الاتصال بالسيارة")

            val now = System.currentTimeMillis()
            val dt = (now - lastTick) / 1000.0
            lastTick = now
            val rpm = live[Pids.RPM]
            val speed = live[Pids.SPEED]
            val fuel = estimateFuel(live)
            var km = _state.value.tripKm
            var liters = _state.value.tripLiters
            if (rpm != null && rpm > 300 && dt < 5) {
                km += (speed ?: 0.0) * dt / 3600.0
                liters += (fuel ?: 0.0) * dt / 3600.0
                tripSecD += dt
                recorder.start()
                recorder.record(rpm, speed, live[Pids.COOLANT], live[Pids.LOAD], live[Pids.THROTTLE], fuel, battery)
            }
            val snapshot = HashMap(live)
            val load = live[Pids.LOAD]
            val map = live[Pids.MAP]
            if (rpm != null && rpm >= 1800 && load != null && load >= 75 && map != null) {
                boostPeak = maxOf(boostPeak ?: 0.0, map)
            }
            val findings = Diagnostics.analyze(snapshot, battery) +
                listOfNotNull(Boost.finding(_state.value.turbo, boostPeak, live[Pids.BARO]))
            _state.update {
                it.copy(live = snapshot, battery = battery, fuelLph = fuel, findings = findings,
                    tripKm = km, tripLiters = liters, tripSeconds = tripSecD.toInt(), boostPeakKpa = boostPeak)
            }

            // مراقبة الأعطال المتقطعة أثناء القيادة كل 20 ثانية
            if (now - lastDtc > 20_000 && rpm != null && rpm > 300) {
                lastDtc = now
                try {
                    val st = mutex.withLock { e.storedCodes() }
                    val pe = mutex.withLock { e.pendingCodes() }
                    val all = ((st ?: emptyList()) + (pe ?: emptyList())).toSet()
                    val fresh = all - seen
                    if (fresh.isNotEmpty()) {
                        seen += fresh
                        val c = fresh.first()
                        addLog("عطل جديد أثناء القيادة: $fresh")
                        _state.update {
                            it.copy(alert = "عطل جديد: $c — ${Dtc.lookup(c).title}",
                                stored = st ?: it.stored, pending = pe ?: it.pending, faultsRead = true)
                        }
                    }
                } catch (x: ObdException) {
                    // المحاولة التالية بعد 20 ثانية
                }
            }
            delay(30)
        }
    }

    /**
     * معدل الوقود (لتر/ساعة): من PID مباشر إن وُجد. للبنزين يُقدَّر من MAF.
     * في الديزل لا يُقدَّر من MAF لأن نسبة الهواء/الوقود تتغير كثيرًا فتضلّل الرقم.
     */
    private fun estimateFuel(v: Map<Int, Double>): Double? {
        v[Pids.FUEL_RATE]?.let { return it }
        if (_state.value.diesel) return null
        val maf = v[Pids.MAF] ?: return null
        return maf * 3600.0 / (14.7 * 745.0)
    }

    // ---------- الأعطال ----------

    fun readFaults() {
        val e = elm ?: return notice("اتصل بالسيارة أولًا")
        scope.launch {
            _state.update { it.copy(busy = "جارٍ قراءة الأعطال…") }
            try {
                mutex.withLock {
                    val stored = e.storedCodes()
                    val pending = e.pendingCodes()
                    val ready = e.readiness()
                    val freeze = if (!stored.isNullOrEmpty()) e.freezeFrame() else emptyMap()
                    addLog("قراءة الأعطال: stored=$stored pending=$pending")
                    _state.update {
                        it.copy(stored = stored, pending = pending, readiness = ready, freeze = freeze,
                            faultsRead = true, notice = null)
                    }
                }
            } catch (x: Exception) {
                notice(x.message ?: "تعذّرت القراءة")
            } finally {
                _state.update { it.copy(busy = null) }
            }
        }
    }

    fun clearFaults() {
        val e = elm ?: return notice("اتصل بالسيارة أولًا")
        scope.launch {
            _state.update { it.copy(busy = "جارٍ مسح الأعطال…") }
            try {
                val ok = mutex.withLock { e.clearCodes() }
                _state.update { it.copy(notice = if (ok) "تم مسح الأعطال. قد تعود إن بقي السبب." else "رفضت السيارة المسح") }
            } catch (x: Exception) {
                notice(x.message ?: "تعذّر المسح")
            } finally {
                _state.update { it.copy(busy = null) }
            }
        }
        scope.launch { delay(1500); readFaults() }
    }

    /** فحص عميق: كل ما تدعمه السيارة قياسيًا، ثم خلاصة وتقرير نصي. */
    fun deepScan() {
        val e = elm ?: return notice("اتصل بالسيارة أولًا")
        scope.launch {
            try {
                addLog("=== بدء الفحص العميق ===")
                fun step(msg: String) { _state.update { it.copy(busy = msg) } }
                step("1/7 الأعطال المخزّنة…")
                val stored = mutex.withLock { e.storedCodes() }
                step("2/7 الأعطال المعلّقة…")
                val pending = mutex.withLock { e.pendingCodes() }
                step("3/7 الأعطال الدائمة…")
                val permanent = mutex.withLock { e.permanentCodes() }
                step("4/7 العدّادات…")
                val counters = mutex.withLock { e.counters() }
                step("5/7 جاهزية الفحص…")
                val ready = mutex.withLock { e.readiness() }
                step("6/7 لقطة التجميد ومعلومات الوحدة…")
                val any = !stored.isNullOrEmpty() || !pending.isNullOrEmpty()
                val freeze = if (any) mutex.withLock { e.freezeFrame() } else emptyMap()
                val ecu = mutex.withLock { e.infoText(0x0A) }
                val cal = mutex.withLock { e.infoText(0x04) }
                step("7/7 الاختبارات الذاتية (قد تستغرق دقيقة)…")
                val mids = mutex.withLock { e.mode06Supported() }
                val tests = mutableListOf<TestResult>()
                for ((i, mid) in mids.take(40).withIndex()) {
                    step("7/7 الاختبارات الذاتية ${i + 1}/${minOf(mids.size, 40)}…")
                    try { tests += mutex.withLock { e.mode06Read(mid) } } catch (x: ObdException) { }
                }
                val baro = _state.value.live[Pids.BARO]
                val verdicts = DeepAnalyzer.verdicts(stored, pending, permanent, counters, ready, tests,
                    _state.value.turbo, boostPeak, baro)
                val report = DeepReport(_state.value.vin, ecu, cal, stored, pending, permanent, counters,
                    ready, freeze, tests, verdicts)
                addLog("=== انتهى الفحص العميق ===\n" + report.toText())
                _state.update {
                    it.copy(deep = report, stored = stored, pending = pending, readiness = ready,
                        freeze = freeze, faultsRead = true)
                }
            } catch (x: Exception) {
                notice(x.message ?: "تعذّر الفحص العميق")
            } finally {
                _state.update { it.copy(busy = null) }
            }
        }
    }

    fun dismissAlert() { _state.update { it.copy(alert = null) } }

    private fun notice(msg: String) { _state.update { it.copy(notice = msg) } }
    fun dismissNotice() { _state.update { it.copy(notice = null) } }

    // ---------- الرحلات والإعدادات ----------

    fun refreshTrips() {
        scope.launch {
            val t = TripStore.list(app)
            _state.update { it.copy(trips = t) }
        }
    }

    fun deleteTrip(t: TripSummary) {
        scope.launch { TripStore.delete(t); refreshTrips() }
    }

    fun shareTrip(t: TripSummary) = TripStore.share(app, t)

    fun setImperial(v: Boolean) { settings.imperial = v; _state.update { it.copy(imperial = v) } }
    fun setDiesel(v: Boolean) { settings.diesel = v; _state.update { it.copy(diesel = v) } }
    fun setTurbo(v: Boolean) { settings.turbo = v; _state.update { it.copy(turbo = v) } }
    fun setAutoReconnect(v: Boolean) { settings.autoReconnect = v; _state.update { it.copy(autoReconnect = v) } }
}
