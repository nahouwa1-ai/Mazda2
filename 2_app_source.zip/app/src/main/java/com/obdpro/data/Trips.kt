package com.obdpro.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TripSummary(
    val file: File,
    val startMillis: Long,
    val durationSec: Int,
    val distanceKm: Double,
    val avgSpeed: Double,
    val maxSpeed: Double,
    val maxRpm: Double,
    val fuelLiters: Double
) {
    val lPer100: Double? get() = if (distanceKm > 0.5) fuelLiters / distanceKm * 100 else null
}

/** يسجّل الرحلة الحالية في ملف CSV. */
class TripRecorder(private val context: Context) {
    private var writer: BufferedWriter? = null
    private var file: File? = null
    private var count = 0

    val active get() = writer != null

    fun start() {
        if (writer != null) return
        val dir = File(context.filesDir, "trips").apply { mkdirs() }
        val name = "trip_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".csv"
        val f = File(dir, name)
        file = f
        writer = BufferedWriter(FileWriter(f)).also {
            it.write("time_ms,rpm,speed_kmh,coolant_c,load_pct,throttle_pct,fuel_lph,voltage\n")
        }
    }

    fun record(rpm: Double?, speed: Double?, coolant: Double?, load: Double?,
               throttle: Double?, fuelLph: Double?, voltage: Double?) {
        val w = writer ?: return
        fun f(d: Double?) = d?.let { "%.2f".format(Locale.US, it) } ?: ""
        w.write("${System.currentTimeMillis()},${f(rpm)},${f(speed)},${f(coolant)},${f(load)},${f(throttle)},${f(fuelLph)},${f(voltage)}\n")
        if (++count % 5 == 0) w.flush()
    }

    fun stop() {
        try { writer?.flush(); writer?.close() } catch (_: Exception) {}
        val f = file
        writer = null; file = null; count = 0
        // حذف الرحلات الفارغة
        if (f != null && f.exists() && f.readLines().size < 6) f.delete()
    }
}

object TripStore {
    private fun dir(c: Context) = File(c.filesDir, "trips").apply { mkdirs() }

    fun list(c: Context): List<TripSummary> =
        (dir(c).listFiles { f -> f.extension == "csv" } ?: emptyArray())
            .sortedByDescending { it.name }
            .mapNotNull { summarize(it) }

    fun summarize(f: File): TripSummary? {
        return try {
            val rows = f.readLines().drop(1).map { it.split(",") }.filter { it.size >= 8 }
            if (rows.size < 2) return null
            var distance = 0.0; var fuel = 0.0
            var maxSpeed = 0.0; var maxRpm = 0.0; var speedSum = 0.0; var speedN = 0
            for (i in 1 until rows.size) {
                val dt = (rows[i][0].toLong() - rows[i - 1][0].toLong()) / 1000.0
                if (dt <= 0 || dt > 10) continue
                val sp = rows[i][2].toDoubleOrNull() ?: 0.0
                distance += sp * dt / 3600.0
                fuel += (rows[i][6].toDoubleOrNull() ?: 0.0) * dt / 3600.0
            }
            for (r in rows) {
                val sp = r[2].toDoubleOrNull()
                if (sp != null) { maxSpeed = maxOf(maxSpeed, sp); if (sp > 0) { speedSum += sp; speedN++ } }
                r[1].toDoubleOrNull()?.let { maxRpm = maxOf(maxRpm, it) }
            }
            val start = rows.first()[0].toLong()
            val dur = ((rows.last()[0].toLong() - start) / 1000).toInt()
            TripSummary(f, start, dur, distance, if (speedN > 0) speedSum / speedN else 0.0, maxSpeed, maxRpm, fuel)
        } catch (e: Exception) { null }
    }

    fun delete(t: TripSummary) { t.file.delete() }

    fun share(c: Context, t: TripSummary) {
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", t.file)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        c.startActivity(Intent.createChooser(i, "تصدير الرحلة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

class Settings(context: Context) {
    private val p = context.getSharedPreferences("obdpro", Context.MODE_PRIVATE)
    var imperial: Boolean
        get() = p.getBoolean("imperial", false)
        set(v) = p.edit().putBoolean("imperial", v).apply()
    var autoReconnect: Boolean
        get() = p.getBoolean("autoReconnect", true)
        set(v) = p.edit().putBoolean("autoReconnect", v).apply()
    var profileVin: String
        get() = p.getString("profileVin", "") ?: ""
        set(v) = p.edit().putString("profileVin", v).apply()
    var turbo: Boolean
        get() = p.getBoolean("turbo", false)
        set(v) = p.edit().putBoolean("turbo", v).apply()
    var diesel: Boolean
        get() = p.getBoolean("diesel", false)
        set(v) = p.edit().putBoolean("diesel", v).apply()
    var wifiHost: String
        get() = p.getString("host", "192.168.0.10") ?: "192.168.0.10"
        set(v) = p.edit().putString("host", v).apply()
    var wifiPort: Int
        get() = p.getInt("port", 35000)
        set(v) = p.edit().putInt("port", v).apply()
    var lastBtAddress: String
        get() = p.getString("bt", "") ?: ""
        set(v) = p.edit().putString("bt", v).apply()
}
